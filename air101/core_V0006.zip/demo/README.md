# LuatOS 演示代码

## 重要提示

库的demo通常都需要配合最新的固件, 如果发现demo有问题, 请先确认是不是最新固件.

最新固件下载地址: https://gitee.com/openLuat/LuatOS/releases

## demo的适用性

* 如果有子文件夹, 例如Air101, 代表该demo可能只适合对应的硬件使用. 但Air101/Air103/W806属于同一类型, 基本通用.
* 不带子文件的,通常是通用demo, 与具体硬件无关, 但使用的固件可能不带对应的库, 就会提示xxx not found 或者 nil xxx
