
local env = {
    wifi_ssid = "uiot",
    wifi_passwd = "12345678"
}

return env
